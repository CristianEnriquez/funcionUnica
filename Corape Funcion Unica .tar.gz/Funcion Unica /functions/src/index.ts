
// The Cloud Functions for Firebase SDK to create Cloud Functions and setup triggers.
const functions = require('firebase-functions');

// The Firebase Admin SDK to access the Firebase Realtime Database.
const admin = require('firebase-admin');
admin.initializeApp();





exports.funcionNacion = functions.https.onRequest((request, response) => {
      


    const preObject = admin.database().ref('/1100').orderByChild('nombre')
    preObject.on('value', (snap) => {
      
     

        var data = snap.val();

     
        response.json(data)
       
   
    });  
 
})

   



exports.funcionPueblo = functions.https.onRequest((request, response) => {
      
    if (!request.query.nacion) {
        response.send('Debe enviar una nacionalidad para obtener el registro')
    }

    const preObject = admin.database().ref('/2200').orderByChild('nacion').equalTo(request.query.nacion)
    preObject.on('value', (snap) => {
      
     

        var data = snap.val();

     
        response.json(data)
       
   
    });  
 
})
  
  